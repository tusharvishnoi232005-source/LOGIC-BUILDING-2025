/* File 175: hello_world.c
   Level: Advanced
   Generated: Example C program
*/

#include <stdio.h>
int main(void) {
    printf("Hello, World!\n");
    return 0;
}
