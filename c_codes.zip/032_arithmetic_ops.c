/* File 032: arithmetic_ops.c
   Level: Advanced
   Generated: Example C program
*/

#include <stdio.h>
int main(void) {
    int a = 7, b = 2;
    printf("a+b=%d a-b=%d a*b=%d a/b=%d a%%b=%d\n", a+b, a-b, a*b, a/b, a%b);
    return 0;
}
