/* File 155: pointers.c
   Level: Advanced
   Generated: Example C program
*/

#include <stdio.h>
int main(void) {
    int x = 6;
    int *p = &x;
    printf("x=%d *p=%d\n", x, *p);
    return 0;
}
