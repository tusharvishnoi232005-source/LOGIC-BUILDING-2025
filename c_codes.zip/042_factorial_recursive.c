/* File 042: factorial_recursive.c
   Level: Advanced
   Generated: Example C program
*/

#include <stdio.h>
long long fact(int n){ return n<=1?1:n*fact(n-1); }
int main(void){ printf("fact(3)=%lld\n", fact(3)); return 0; }
