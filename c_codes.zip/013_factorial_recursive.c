/* File 013: factorial_recursive.c
   Level: Intermediate
   Generated: Example C program
*/

#include <stdio.h>
long long fact(int n){ return n<=1?1:n*fact(n-1); }
int main(void){ printf("fact(4)=%lld\n", fact(4)); return 0; }
