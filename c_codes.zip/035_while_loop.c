/* File 035: while_loop.c
   Level: Advanced
   Generated: Example C program
*/

#include <stdio.h>
int main(void) {
    int i = 1;
    while (i <= 3) { printf("%d ", i); i++; }
    printf("\n");
    return 0;
}
