/* File 172: dynamic_memory.c
   Level: Advanced
   Generated: Example C program
*/

#include <stdio.h>
#include <stdlib.h>
int main(void){
    int n=7;
    int *p = malloc(n * sizeof *p);
    for(int i=0;i<n;i++) p[i]=i+1;
    for(int i=0;i<n;i++) printf("%d ", p[i]);
    printf("\n");
    free(p);
    return 0;
}
