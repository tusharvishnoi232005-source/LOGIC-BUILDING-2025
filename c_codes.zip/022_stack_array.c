/* File 022: stack_array.c
   Level: Advanced
   Generated: Example C program
*/

#include <stdio.h>
#define MAX 4
int main(void){
    int stack[MAX], top=-1;
    stack[++top]=3; stack[++top]=20;
    while(top>=0) printf("%d ", stack[top--]);
    printf("\n");
    return 0;
}
