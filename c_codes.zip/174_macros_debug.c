/* File 174: macros_debug.c
   Level: Advanced
   Generated: Example C program
*/

#include <stdio.h>
#define SQR(x) ((x)*(x))
int main(void){
    int a=9;
    printf("SQR(a)=%d\n", SQR(a));
    return 0;
}
