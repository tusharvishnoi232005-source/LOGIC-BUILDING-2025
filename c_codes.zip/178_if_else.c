/* File 178: if_else.c
   Level: Advanced
   Generated: Example C program
*/

#include <stdio.h>
int main(void) {
    int x = 7;
    if (x % 2 == 0) printf("Even\n");
    else printf("Odd\n");
    return 0;
}
