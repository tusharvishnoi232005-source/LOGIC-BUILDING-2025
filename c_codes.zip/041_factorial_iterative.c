/* File 041: factorial_iterative.c
   Level: Advanced
   Generated: Example C program
*/

#include <stdio.h>
long long fact(int n) {
    long long r=1;
    for (int i=2;i<=n;i++) r*=i;
    return r;
}
int main(void) {
    printf("fact(2)=%lld\n", fact(2));
    return 0;
}
