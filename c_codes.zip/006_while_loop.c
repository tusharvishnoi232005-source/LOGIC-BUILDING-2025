/* File 006: while_loop.c
   Level: Basic
   Generated: Example C program
*/

#include <stdio.h>
int main(void) {
    int i = 1;
    while (i <= 9) { printf("%d ", i); i++; }
    printf("\n");
    return 0;
}
