/* File 071: factorial_recursive.c
   Level: Advanced
   Generated: Example C program
*/

#include <stdio.h>
long long fact(int n){ return n<=1?1:n*fact(n-1); }
int main(void){ printf("fact(2)=%lld\n", fact(2)); return 0; }
