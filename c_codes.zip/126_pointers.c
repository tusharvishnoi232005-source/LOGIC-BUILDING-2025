/* File 126: pointers.c
   Level: Advanced
   Generated: Example C program
*/

#include <stdio.h>
int main(void) {
    int x = 7;
    int *p = &x;
    printf("x=%d *p=%d\n", x, *p);
    return 0;
}
