/* File 147: variables_types.c
   Level: Advanced
   Generated: Example C program
*/

#include <stdio.h>
int main(void) {
    int a = 8;
    float b = 3.14f;
    char c = 'A';
    printf("int=%d, float=%.2f, char=%c\n", a, b, c);
    return 0;
}
