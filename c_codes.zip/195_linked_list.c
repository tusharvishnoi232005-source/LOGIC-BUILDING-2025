/* File 195: linked_list.c
   Level: Advanced
   Generated: Example C program
*/

#include <stdio.h>
#include <stdlib.h>
struct Node { int val; struct Node *next; };
int main(void){
    struct Node *head = malloc(sizeof *head);
    head->val = 1; head->next = malloc(sizeof *head);
    head->next->val = 2; head->next->next = NULL;
    for (struct Node *p=head; p; p=p->next) printf("%d ", p->val);
    printf("\n");
    // free
    free(head->next); free(head);
    return 0;
}
