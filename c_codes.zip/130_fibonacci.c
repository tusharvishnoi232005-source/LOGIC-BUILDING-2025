/* File 130: fibonacci.c
   Level: Advanced
   Generated: Example C program
*/

#include <stdio.h>
int main(void) {
    int n=1, a=0,b=1;
    for (int i=0;i<n;i++){ printf("%d ", a); int t=a+b; a=b; b=t; }
    printf("\n");
    return 0;
}
