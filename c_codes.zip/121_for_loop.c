/* File 121: for_loop.c
   Level: Advanced
   Generated: Example C program
*/

#include <stdio.h>
int main(void) {
    for (int i=1;i<=5;i++) printf("%d ", i);
    printf("\n");
    return 0;
}
