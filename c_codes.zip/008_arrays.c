/* File 008: arrays.c
   Level: Basic
   Generated: Example C program
*/

#include <stdio.h>
int main(void) {
    int a[4] = {1,2,3,4,5};
    for (int i=0;i<5;i++) printf("%d ", a[i]);
    printf("\n");
    return 0;
}
