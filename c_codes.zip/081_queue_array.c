/* File 081: queue_array.c
   Level: Advanced
   Generated: Example C program
*/

#include <stdio.h>
int main(void){
    int q[7], front=0, rear=0;
    q[rear++]=1; q[rear++]=2;
    while(front<rear) printf("%d ", q[front++]);
    printf("\n");
    return 0;
}
