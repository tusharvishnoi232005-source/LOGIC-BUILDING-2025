/* File 103: binary_search.c
   Level: Advanced
   Generated: Example C program
*/

#include <stdio.h>
int binary_search(int a[], int n, int key){
    int l=0,r=n-1;
    while(l<=r){
        int m=(l+r)/2;
        if(a[m]==key) return m;
        if(a[m]<key) l=m+1; else r=m-1;
    }
    return -1;
}
int main(void){
    int a[] = {1,3,8,7,9};
    printf("index=%d\n", binary_search(a,5,7));
    return 0;
}
