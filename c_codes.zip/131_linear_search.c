/* File 131: linear_search.c
   Level: Advanced
   Generated: Example C program
*/

#include <stdio.h>
int linear_search(int arr[], int n, int key){
    for(int i=0;i<n;i++) if(arr[i]==key) return i;
    return -1;
}
int main(void){
    int a[] = {3,8,2,9,1};
    printf("index=%d\n", linear_search(a,5,9));
    return 0;
}
