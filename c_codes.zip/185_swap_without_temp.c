/* File 185: swap_without_temp.c
   Level: Advanced
   Generated: Example C program
*/

#include <stdio.h>
int main(void) {
    int a = 6, b = 8;
    a = a + b; b = a - b; a = a - b;
    printf("a=%d b=%d\n", a, b);
    return 0;
}
