/* File 157: factorial_iterative.c
   Level: Advanced
   Generated: Example C program
*/

#include <stdio.h>
long long fact(int n) {
    long long r=1;
    for (int i=2;i<=n;i++) r*=i;
    return r;
}
int main(void) {
    printf("fact(8)=%lld\n", fact(8));
    return 0;
}
