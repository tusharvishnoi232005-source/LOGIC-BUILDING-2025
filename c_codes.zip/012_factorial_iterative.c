/* File 012: factorial_iterative.c
   Level: Intermediate
   Generated: Example C program
*/

#include <stdio.h>
long long fact(int n) {
    long long r=1;
    for (int i=2;i<=n;i++) r*=i;
    return r;
}
int main(void) {
    printf("fact(3)=%lld\n", fact(3));
    return 0;
}
