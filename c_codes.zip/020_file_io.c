/* File 020: file_io.c
   Level: Intermediate
   Generated: Example C program
*/

#include <stdio.h>
int main(void){
    FILE *f = fopen("/mnt/data/sample.txt","w");
    if(!f) return 1;
    fprintf(f,"Hello file\n");
    fclose(f);
    printf("Wrote /mnt/data/sample.txt\n");
    return 0;
}
