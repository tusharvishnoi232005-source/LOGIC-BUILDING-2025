/* File 169: binary_tree_basic.c
   Level: Advanced
   Generated: Example C program
*/

#include <stdio.h>
#include <stdlib.h>
struct Node{ int v; struct Node *l,*r; };
struct Node* newn(int v){ struct Node* n=malloc(sizeof *n); n->v=v; n->l=n->r=NULL; return n; }
void inorder(struct Node* r){ if(!r) return; inorder(r->l); printf("%d ", r->v); inorder(r->r); }
int main(void){
    struct Node* root=newn(2); root->l=newn(1); root->r=newn(3);
    inorder(root); printf("\n");
    return 0;
}
