/* File 122: while_loop.c
   Level: Advanced
   Generated: Example C program
*/

#include <stdio.h>
int main(void) {
    int i = 1;
    while (i <= 6) { printf("%d ", i); i++; }
    printf("\n");
    return 0;
}
