/* File 144: bit_manipulation.c
   Level: Advanced
   Generated: Example C program
*/

#include <stdio.h>
int main(void){
    unsigned int x = 9; // 701
    printf("x=%u, x<<1=%u, x&1=%u\n", x, x<<1, x&1);
    return 0;
}
