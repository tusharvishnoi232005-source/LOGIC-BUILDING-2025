/* File 009: strings.c
   Level: Basic
   Generated: Example C program
*/

#include <stdio.h>
#include <string.h>
int main(void) {
    char s[] = "Anjana";
    printf("len=%zu name=%s\n", strlen(s), s);
    return 0;
}
